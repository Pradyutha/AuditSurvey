import axios from "axios";

const CHECKLIST_API_BASE_URL = "/api/checklist";

class checklist {
  getChecklist(auditType, token) {
    return axios.post(`${CHECKLIST_API_BASE_URL}/getChecklist`, auditType, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
  }
  saveResponses(questionsResponse, token) {
    return axios.post(
      `${CHECKLIST_API_BASE_URL}/saveResponses`,
      questionsResponse,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
  }
}

export default new checklist();
