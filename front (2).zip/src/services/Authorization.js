import axios from "axios";

const AUTH_API_BASE_URL = "/api/auth";

class Authorization {
  loginUser(user) {
    return axios.post(`${AUTH_API_BASE_URL}/login`, user, {
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  validateUser(token) {
    return axios.get(`${AUTH_API_BASE_URL}/validate`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  }
}

export default new Authorization();
