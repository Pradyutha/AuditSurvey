import axios from "axios";

const SEVERITY_API_BASE_URL = "/api/severity";

class Severity {
  projectExecutionStatus(auditRequest, token) {
    return axios.post(
      `${SEVERITY_API_BASE_URL}/ProjectExecutionStatus`,
      auditRequest,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
  }
}

export default new Severity();
