import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import Authorization from "../services/Authorization";
import {
  getAuthTokenFromLocalStorage,
  removeAuthTokenFromLocalStorage,
} from "../utils/Utilityhelper";

const Login = (props) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const [credentialError, setCredentialError] = useState(null);
  let history = useHistory();

  useEffect(() => {
    let token = getAuthTokenFromLocalStorage();
    if (token) {
      Authorization.validateUser(token)
        .then((response) => {
          if (response.status === 200) history.push("/home");
        })
        .catch((error) => {
          if (error.response.status === 403) {
            removeAuthTokenFromLocalStorage();
            history.push("/sessionExpired");
          } else history.push("/error");
        });
    }
  }, [history]);

  const onSubmit = (data) => {
    const { username, password } = data;
    if (username && password) {
      const UserCredentials = {
        userId: username,
        password: password,
      };
      Authorization.loginUser(JSON.stringify(UserCredentials))
        .then((response) => {
          if (response.status === 200) return response.data;
        })
        .then((data) => {
          localStorage.setItem("token", data.authToken);
          history.push("/home");
        })
        .catch((error) => {
          if (error.response.status === 403) {
            removeAuthTokenFromLocalStorage();
            history.push("/sessionExpired");
          } else if (error.response.status === 404) {
            setCredentialError(error.response.data.reason);
          } else history.push("/error");
        });
    }
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div style={{ margin: "5px 0px", padding: "10px" }} className="col-11">
          <span className="navbar-brand h1" style={{ fontSize: "55px" }}>
            Audit Management System
          </span>
        </div>
      </nav>
      <div className="container" style={{ margin: "40px 40px" }}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <h3>Sign In</h3>
          <div className="col-4" style={{ margin: "10px 0" }}>
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter username"
              {...register("username", {
                required: "Username is required", // JS only: <p>error message</p> TS only support string
              })}
              onFocus={() => {
                setCredentialError(null);
              }}
            />
            {errors.username && (
              <small className="text-danger">{errors.username.message}</small>
            )}
          </div>
          <div className="col-4" style={{ margin: "10px 0" }}>
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              {...register("password", {
                required: "Password is required", // JS only: <p>error message</p> TS only support string
              })}
              onFocus={() => {
                setCredentialError(null);
              }}
            />
            {errors.password && (
              <small className="text-danger">{errors.password.message}</small>
            )}
          </div>
          {credentialError && (
            <small className="text-danger">{credentialError}</small>
          )}
          <div className="col-3" style={{ margin: "20px 0" }}>
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default Login;
