import React, { Component } from "react";

class Status extends Component {
  render() {
    const { auditResponse } = this.props;
    return (
      <div className="container justify-content-center">
        <div align="center">
          <table
            border="2"
            cellPadding="10"
            className="table-warning table-hover"
            id="table1"
          >
            <tbody>
              <tr>
                <th>Execution status</th>
                <th>Remedial Action</th>
              </tr>

              <tr>
                <td>{auditResponse.projectExecutionStatus}</td>
                <td>{auditResponse.remedialActionDuration}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default Status;
