import React from "react";
import { useForm } from "react-hook-form";
import QuestionItem from "./QuestionItem";

function Questions(props) {
  const { handleSubmit } = useForm();
  const {
    auditType,
    auditQuestions,
    checkStatus,
    handleResponse,
    respondError,
    handleRespondError,
  } = props;
  return (
    <form onSubmit={handleSubmit(checkStatus)} className="container">
      <h3 className="m-4 display-4 text-center">
        <strong>Following are {auditType} Questions</strong>
      </h3>
      {auditQuestions.map((question, index) => (
        <QuestionItem
          question={question}
          key={question.questionId}
          serialNo={index + 1}
          handleResponse={handleResponse}
          handleRespondError={handleRespondError}
        />
      ))}

      {respondError && (
        <div style={{ margin: "20px 0 0 15px" }}>
          <h5 className="text-danger">
            Please provide response for all Questions!!!
          </h5>
        </div>
      )}
      <button
        type="submit"
        style={{ margin: "20px 0 0 15px" }}
        className="btn btn-primary"
      >
        CHECK STATUS
      </button>
    </form>
  );
}

export default Questions;
