import React, { Component } from "react";
import { Link } from "react-router-dom";

class Forbidden extends Component {
  render() {
    return (
      <div className="container" style={{ padding: "80px" }}>
        <h1>Invalid Page Request!</h1>
        <Link style={{ color: "yellow" }} to="/">
          Go To Home Page!!!
        </Link>
      </div>
    );
  }
}

export default Forbidden;
