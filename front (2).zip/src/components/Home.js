import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useHistory } from "react-router-dom";
import Severity from "../services/Severity";
import {
  getAuthTokenFromLocalStorage,
  logOut,
  removeAuthTokenFromLocalStorage,
} from "../utils/Utilityhelper";
import Checklist from "../services/Checklist";
import Status from "./Status";
import Questions from "./Questions";

function Home(props) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  let history = useHistory();
  const { isLoggedIn } = props || {
    isLoggedIn: getAuthTokenFromLocalStorage() ? true : false,
  };

  const [auditQuestions, setAuditQuestions] = useState([]);
  const [showAuditQuestions, setShowAuditQuestions] = useState(false);
  const [showProjectStatus, setShowProjectStatus] = useState(false);
  const [respondError, setRespondError] = useState(false);

  const [auditRequest, setAuditRequest] = useState({});
  const [auditResponse, setAuditResponse] = useState({});

  const resetEvery = () => {
    auditQuestions.forEach((question) => {
      question.response = "";
    });
    Checklist.saveResponses(
      JSON.stringify(auditQuestions),
      getAuthTokenFromLocalStorage()
    )
      .then((response) => {
        if (response.status === 200) {
          setAuditQuestions([]);
          setShowAuditQuestions(false);
          setShowProjectStatus(false);
          setAuditRequest({});
          setAuditResponse({});
          return response.data;
        }
      })
      .catch((error) => {
        if (error.response.status === 403) {
          removeAuthTokenFromLocalStorage();
          history.push("/sessionExpired");
        } else history.push("/error");
      });
  };

  const onSubmit = (data) => {
    console.log(data);
    const auditReq = {
      projectName: data.projectName,
      projectManagerName: data.projectManagerName,
      applicationOwnerName: data.applicationOwnerName,
      auditDetails: {
        auditType: data.auditType,
        auditDate: new Date().toISOString().split("T")[0].toString(),
      },
    };
    setAuditRequest(auditReq);
    Checklist.getChecklist(
      JSON.stringify(data.auditType),
      getAuthTokenFromLocalStorage()
    )
      .then((response) => {
        if (response.status === 200) return response.data;
      })
      .then((auditQuestions) => {
        console.log(auditQuestions);
        setAuditQuestions(auditQuestions);
        setShowAuditQuestions(true);
      })
      .catch((error) => {
        if (error.response.status === 403) {
          removeAuthTokenFromLocalStorage();
          history.push("/sessionExpired");
        } else history.push("/error");
      });
  };

  const saveResponse = (qId, resp) => {
    let editedAuditQuestions = auditQuestions;
    let index = editedAuditQuestions.findIndex(
      (question) => question.questionId === qId
    );
    editedAuditQuestions[index].response = resp;
    console.log(editedAuditQuestions);
    setAuditQuestions(editedAuditQuestions);
  };

  const checkStatus = (e) => {
    //console.log(e);//here e is not the event object on which we can call e.preventDefault()
    //rather when we use react-hook-form it is the data object passed i.e data from the differnrt form input fields
    let unrespondedQuestion = auditQuestions.find(
      (question) => question.response === ""
    );
    if (unrespondedQuestion) setRespondError(true);
    else {
      Checklist.saveResponses(
        JSON.stringify(auditQuestions),
        getAuthTokenFromLocalStorage()
      )
        .then((response) => {
          if (response.status === 200) return response.data;
        })
        .then((respdata) => {
          Severity.projectExecutionStatus(
            JSON.stringify(auditRequest),
            getAuthTokenFromLocalStorage()
          )
            .then((response) => {
              return response.data;
            })
            .then((responseData) => {
              setAuditResponse(responseData);
              setShowAuditQuestions(false);
              setShowProjectStatus(true);
            })
            .catch((error) => {
              if (error.response.status === 403) {
                removeAuthTokenFromLocalStorage();
                history.push("/sessionExpired");
              } else history.push("/error");
            });
        })
        .catch((error) => {
          if (error.response.status === 403) {
            removeAuthTokenFromLocalStorage();
            history.push("/sessionExpired");
          } else history.push("/error");
        });
    }
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light ">
        <div style={{ margin: "5px 0px", padding: "5px" }} className="clearfix">
          <span className="navbar-brand h1 float-start">
            Audit Management System
          </span>
          {isLoggedIn ? (
            <button onClick={() => logOut(history)} className="float-end">
              <span>Logout</span>
            </button>
          ) : (
            <button className="float-end">
              <Link to="/" style={{ textDecoration: "none", color: "yellow" }}>
                <h5>Log in</h5>
              </Link>
            </button>
          )}
        </div>
      </nav>

      <div className="container">
        {isLoggedIn && !showAuditQuestions && !showProjectStatus && (
          <>
            {" "}
            <h3
              className="m-4 text-center display-4"
              style={{ color: "black" }}
            >
              <strong>Project Details</strong>
            </h3>
            <div className="row justify-content-center">
              <form onSubmit={handleSubmit(onSubmit)} className="col-6">
                <div className="mb-3 w-50">
                  <label>
                    <h5>Project Name</h5>
                  </label>
                  <input
                    {...register("projectName", {
                      required: true,
                      maxLength: 90,
                    })}
                  />
                  {errors?.projectName?.type === "required" && (
                    <p>This field is required</p>
                  )}
                  {errors?.projectName?.type === "maxLength" && (
                    <p>Project name cannot exceed 90 characters</p>
                  )}
                </div>
                <div className="mb-3 w-50">
                  <label>
                    <h5>Project Manager Name</h5>
                  </label>
                  <input
                    {...register("projectManagerName", {
                      required: true,
                      maxLength: 90,
                    })}
                  />
                  {errors?.projectManagerName?.type === "required" && (
                    <p>This field is required</p>
                  )}
                  {errors?.projectManagerName?.type === "maxLength" && (
                    <p>Project Manager name cannot exceed 90 characters</p>
                  )}
                </div>
                <div className="mb-3 w-50">
                  <label>
                    <h5>Application Owner</h5>
                  </label>
                  <input
                    {...register("applicationOwnerName", {
                      required: true,
                      maxLength: 90,
                    })}
                  />
                  {errors?.applicationOwnerName?.type === "required" && (
                    <p>This field is required</p>
                  )}
                  {errors?.applicationOwnerName?.type === "maxLength" && (
                    <p>Owner name cannot exceed 90 characters</p>
                  )}
                </div>
                <div className="mb-3 w-50">
                  <div className="form-check">
                    <input
                      {...register("auditType", { required: true })}
                      className="form-check-input"
                      type="radio"
                      value="Internal"
                      id="field-Internal"
                    />
                    <label
                      htmlFor="field-Internal"
                      className="form-check-label"
                    >
                      Internal
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      {...register("auditType", { required: true })}
                      className="form-check-input"
                      type="radio"
                      value="SOX"
                      id="field-SOX"
                    />
                    <label className="form-check-label" htmlFor="field-SOX">
                      SOX
                    </label>
                  </div>
                  {errors?.auditType?.type === "required" && (
                    <p>This field is required</p>
                  )}
                </div>
                <div className="mb-3 w-50">
                  <button type="submit" className="btn btn-primary">
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </>
        )}

        {showAuditQuestions && auditQuestions.length > 0 && (
          <Questions
            auditQuestions={auditQuestions}
            auditType={auditRequest.auditDetails.auditType}
            checkStatus={checkStatus}
            handleResponse={saveResponse}
            respondError={respondError}
            handleRespondError={setRespondError}
          />
        )}
        {showProjectStatus && <Status auditResponse={auditResponse} />}
        {showProjectStatus && (
          <div align="center">
            <button onClick={resetEvery} className="btn btn-primary">
              RESET
            </button>
          </div>
        )}
      </div>
    </>
  );
}

export default Home;
