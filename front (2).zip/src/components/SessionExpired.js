import React, { Component } from "react";
import { Link } from "react-router-dom";

class SessionExpired extends Component {
  render() {
    return (
      <div>
        <h1>Audit Management System</h1>
        <div className="text-center container mt-4">
          <img
            src="https://img.icons8.com/dusk/64/000000/expired.png"
            alt="images"
          />
          <h1>Session Expired !!</h1>
          <Link to="/" style={{ color: "yellow" }}>
            Login Again
          </Link>
        </div>
      </div>
    );
  }
}

export default SessionExpired;
