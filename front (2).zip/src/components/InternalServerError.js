import React, { Component } from "react";
import { Link } from "react-router-dom";

class InternalServerError extends Component {
  render() {
    return (
      <div>
        <h1>Internal Server Error!</h1>
        <Link to="/" style={{ color: "yellow" }}>
          Please login again
        </Link>
      </div>
    );
  }
}

export default InternalServerError;
