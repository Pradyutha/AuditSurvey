import React from "react";
import { Redirect, Route } from "react-router-dom";
import { getAuthTokenFromLocalStorage } from "../utils/Utilityhelper";

const PrivateRoute = (privateRouteProps) => {
  const { path, component: Component } = privateRouteProps;
  const isLoggedIn = getAuthTokenFromLocalStorage() ? true : false;
  return (
    <Route
      path={path}
      render={(props) => {
        return isLoggedIn ? (
          <Component {...props} isLoggedIn={isLoggedIn} />
        ) : (
          <Redirect
            to={{
              //this object we are passing in the "to" property is loaction object passed as props to the component
              //which is to be renderered on the given path mentioned in pathname property
              pathname: "/",
              state: {
                //here whatever data we give inside the state is passed to the component
                //which is to be renderered on the given path mentioned in pathname property and
                //here on this path we are rendering login component
                from: props.location, // location is a object like { pathname: "/somepath" ,and some other properties }so it is the actual location where user is trying to access
                //
              },
            }}
          />
        );
      }}
    />
  );
};

export default PrivateRoute;
