import React from "react";

function QuestionItem(props) {
  const { question, serialNo, handleResponse, handleRespondError } = props;
  return (
    <div
      onChange={(e) => handleResponse(question.questionId, e.target.value)}
      className="form-check"
      onFocus={() => {
        handleRespondError(false);
      }}
    >
      <h6>
        {serialNo} . {question.question}{" "}
      </h6>
      <div className="form-check">
        <input
          // {...register("radio" + serialNo, { required: true })}
          className="form-check-input"
          type="radio"
          name={serialNo}
          id={"flex1" + serialNo}
          value="YES"
        />
        <label className="form-check-label" htmlFor={"flex1" + serialNo}>
          YES
        </label>
      </div>
      <div className="form-check">
        <input
          // {...register("radio" + serialNo, { required: true })}
          className="form-check-input"
          type="radio"
          name={serialNo}
          id={"flex2" + serialNo}
          value="NO"
        />
        <label className="form-check-label" htmlFor={"flex2" + serialNo}>
          NO
        </label>
      </div>
      {/* {errors?.[`radio${serialNo}`]?.type === "required" && (
        <small>Please provide some response here!</small>
      )} */}
    </div>
  );
}

export default QuestionItem;
