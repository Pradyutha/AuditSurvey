import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Login from "./components/Login";
import Home from "./components/Home";

import PrivateRoute from "./components/PrivateRoute";
import SessionExpired from "./components/SessionExpired";
import InternalServerError from "./components/InternalServerError";
import Forbidden from "./components/Forbidden";
const App = () => {
  return (
    <div className="Container">
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Login} />
          <Route exact path="/sessionExpired" component={SessionExpired} />
          <Route exact path="/error" component={InternalServerError} />
          <PrivateRoute exact path="/home" component={Home} />
          <Route component={Forbidden} />
        </Switch>
      </BrowserRouter>
    </div>
  );
};

export default App;
